package bean;

public class Concert {

	private int concert_id;
	private String concert_name;
	private int ticket_price;
	private String spec;
	private String venue;
	private String location;
	private String concert_date;
	private String concert_time;
	private String image_url;
	public Concert() {
		super();
		this.concert_id = concert_id;
		this.concert_name = concert_name;
		this.ticket_price = ticket_price;
	}
	public int getConcert_id() {
		return concert_id;
	}
	public void setConcert_id(int concert_id) {
		this.concert_id = concert_id;
	}
	public String getConcert_name() {
		return concert_name;
	}
	public void setConcert_name(String concert_name) {
		this.concert_name = concert_name;
	}
	public int getTicket_price() {
		return ticket_price;
	}
	public void setTicket_price(double d) {
		this.ticket_price = (int) d;
	}
	public String getSpec() {
		return spec;
	}
	public void setSpec(String spec) {
		this.spec = spec;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getConcert_date() {
		return concert_date;
	}
	public void setConcert_date(String concert_date) {
		this.concert_date = concert_date;
	}
	public String getConcert_time() {
		return concert_time;
	}
	public void setConcert_time(String concert_time) {
		this.concert_time = concert_time;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	
	
}

	